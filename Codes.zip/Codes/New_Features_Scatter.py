import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Define file paths and dataset names
file_paths = [
    r"C:\Users\M.Hosein\Desktop\Everything About Paper\Figures\Pattern and Corelation\Makran_edited.csv",
    r"C:\Users\M.Hosein\Desktop\Everything About Paper\Figures\Pattern and Corelation\Geshm_edited.csv",
    r"C:\Users\M.Hosein\Desktop\Everything About Paper\Figures\Pattern and Corelation\UAE_edited.csv"
]
dataset_names = ['A) Makran', 'B) Geshm', 'C) UAE']

# Initialize the figure with a 3x3 grid
fig, axs = plt.subplots(4, 3, figsize=(24, 24))  # Adjust figsize as needed

# Titles for each column
for col, name in enumerate(dataset_names):
    axs[0, col].set_title(name, fontsize=16)

# Plotting function
def plot_data(df, axs, col):
    # Create classification columns
    df['Class'] = df['Chl_a'] > 10
    df['Class'] = df['Class'].map({True: 'Bloom', False: 'NoN Bloom'})
    
    # Plot for the present month: SST vs Chl_a
    sns.scatterplot(data=df, x='SST_STD_12months', y='Chl_a', hue='Class', palette={'Bloom': 'red', 'NoN Bloom': 'blue'}, alpha=0.7, ax=axs[0, col])
    axs[0, col].set_xlabel('SST 12 Months SD (°C)')
    axs[0, col].set_ylabel('Chl_a (mg/m^3)')
    axs[0, col].legend(loc='upper left')

  # Plot for the present month: SST vs Chl_a
    sns.scatterplot(data=df, x='STD_100Km', y='Chl_a', hue='Class', palette={'Bloom': 'red', 'NoN Bloom': 'blue'}, alpha=0.7, ax=axs[1, col])
    axs[1, col].set_xlabel('SST 100 KM SD (°C)')
    axs[1, col].set_ylabel('Chl_a (mg/m^3)')
    axs[1, col].legend().set_visible(False)

    # Plot for the present month: Salinity vs Chl_a
    sns.scatterplot(data=df, x='Salinity_STD_6months', y='Chl_a', hue='Class', palette={'Bloom': 'red', 'NoN Bloom': 'blue'}, alpha=0.7, ax=axs[2, col])
    axs[2, col].set_xlabel('Salinity 6 Months SD (PSU)')
    axs[2, col].set_ylabel('Chl_a (mg/m^3)')
    axs[2, col].legend().set_visible(False)

    # Plot for the present month: Wind Speed vs Chl_a
    sns.scatterplot(data=df, x='SSGF', y='Chl_a', hue='Class', palette={'Bloom': 'red', 'NoN Bloom': 'blue'}, alpha=0.7, ax=axs[3, col])
    axs[3, col].set_xlabel('SSGF (°C)')
    axs[3, col].set_ylabel('Chl_a (mg/m^3)')
    axs[3, col].legend().set_visible(False)

# Load and plot each dataset
for i, (file_path, name) in enumerate(zip(file_paths, dataset_names)):
    df = pd.read_csv(file_path, encoding='latin-1')
    plot_data(df, axs, i)

# Adjust layout
plt.tight_layout(pad=10)

# Save the figure with a high resolution
plt.savefig('SST_Family.png', dpi=300)
plt.show()
